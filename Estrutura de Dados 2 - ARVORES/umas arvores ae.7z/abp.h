struct TNOABP{
	int chave;
	struct TNOABP *dir;
	struct TNOABP *esq;
};

typedef struct TNOABP TNOABP;

TNOABP *buscaABP(TNOABP *raiz, int k);
