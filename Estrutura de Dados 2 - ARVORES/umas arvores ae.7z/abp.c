#include "abp.h"

main(){
	
TNOABP *buscaABP(TNOABP *raiz, int k){
	if(raiz==NULL)  // if (ini>fim)
		return NULL;
	if(raiz->chave == k) //como se fosse o meio da BBIN 
		return raiz;
	if(raiz->chave < k) 
		return buscaABP(raiz->dir, k);
	else
		return buscaABP(raiz->esq, k);
}


}
